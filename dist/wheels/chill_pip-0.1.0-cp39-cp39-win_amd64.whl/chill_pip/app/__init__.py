from .app import app, secret_function

__all__ = ['app', 'secret_function'] 